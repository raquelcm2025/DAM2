import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtContrasenia: UITextField!
    @IBOutlet weak var botonIngresar: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func ingresarCuenta(_ sender: Any) {
        guard let email = txtEmail.text, !email.isEmpty,
              let contrasenia = txtContrasenia.text, !contrasenia.isEmpty else {
            mostrarAlerta("Por favor ingresa tu correo y contraseña.")
            return
        }

        botonIngresar.isEnabled = false
        activityIndicator.startAnimating()

        Auth.auth().signIn(withEmail: email, password: contrasenia) { [weak self] _, error in
            guard let self = self else { return }
            self.botonIngresar.isEnabled = true
            self.activityIndicator.stopAnimating()

            if let error = error {
                self.mostrarAlerta(error.localizedDescription)
                return
            }

            if let sceneDelegate = self.view.window?.windowScene?.delegate as? SceneDelegate {
                sceneDelegate.mostrarTareas()
            }
        }
    }

    @IBAction func irACrearCuenta(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let registroVC = storyboard.instantiateViewController(withIdentifier: "RegistroVC")
        navigationController?.pushViewController(registroVC, animated: true)
    }

    @IBAction func irARecuperar(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let recuperarVC = storyboard.instantiateViewController(withIdentifier: "RecuperarVC")
        navigationController?.pushViewController(recuperarVC, animated: true)
    }

    func mostrarAlerta(_ mensaje: String) {
        let alerta = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        alerta.addAction(UIAlertAction(title: "OK", style: .default))
        present(alerta, animated: true)
    }
}
