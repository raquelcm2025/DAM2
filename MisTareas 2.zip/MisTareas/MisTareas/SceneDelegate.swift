import UIKit
import FirebaseAuth

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        window = UIWindow(windowScene: windowScene)

        if Auth.auth().currentUser != nil {
            mostrarTareas()
        } else {
            mostrarLogin()
        }

        window?.makeKeyAndVisible()
    }

    func mostrarLogin() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginNav = storyboard.instantiateViewController(withIdentifier: "LoginNav")

        guard let window = window else { return }
        UIView.transition(with: window, duration: 0.3, options: .transitionCrossDissolve) {
            window.rootViewController = loginNav
        }
    }

    func mostrarTareas() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let tareasNav = storyboard.instantiateViewController(withIdentifier: "TareasNav")

        guard let window = window else { return }
        UIView.transition(with: window, duration: 0.3, options: .transitionCrossDissolve) {
            window.rootViewController = tareasNav
        }
    }

    func sceneDidDisconnect(_ scene: UIScene) {}
    func sceneDidBecomeActive(_ scene: UIScene) {}
    func sceneWillResignActive(_ scene: UIScene) {}
    func sceneWillEnterForeground(_ scene: UIScene) {}
    func sceneDidEnterBackground(_ scene: UIScene) {}
}
