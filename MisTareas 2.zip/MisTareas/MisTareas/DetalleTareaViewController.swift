import UIKit

class DetalleTareaViewController: UIViewController {
    
    var nombreTarea: String = ""
    var alEditarTarea: ((String) -> Void)?
    
    let txtTarea = UITextField()
    let txtEstado = UITextField()
    let botonCompletar = UIButton(type: .system)
    let botonEditar = UIButton(type: .system)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Detalle de tarea"
        view.backgroundColor = .systemBackground
        
        configurarVista()
    }
    
    func configurarVista() {
        let lblTarea = UILabel()
        lblTarea.text = "Tarea"
        
        txtTarea.text = nombreTarea
        txtTarea.borderStyle = .roundedRect
        txtTarea.isEnabled = false
        
        let lblEstado = UILabel()
        lblEstado.text = "Estado"
        
        txtEstado.text = "Pendiente"
        txtEstado.borderStyle = .roundedRect
        txtEstado.isEnabled = false
        
        botonCompletar.setTitle("Marcar como completada", for: .normal)
        botonCompletar.backgroundColor = .systemGray5
        botonCompletar.layer.cornerRadius = 8
        botonCompletar.heightAnchor.constraint(equalToConstant: 45).isActive = true
        botonCompletar.addTarget(self, action: #selector(marcarComoCompletada), for: .touchUpInside)
        
        botonEditar.setTitle("Editar tarea", for: .normal)
        botonEditar.backgroundColor = .systemGray5
        botonEditar.layer.cornerRadius = 8
        botonEditar.heightAnchor.constraint(equalToConstant: 45).isActive = true
        botonEditar.addTarget(self, action: #selector(editarTarea), for: .touchUpInside)
        
        let stack = UIStackView(arrangedSubviews: [
            lblTarea,
            txtTarea,
            lblEstado,
            txtEstado,
            botonCompletar,
            botonEditar
        ])
        
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
        ])
    }
    
    @objc func marcarComoCompletada() {
        txtEstado.text = "Completada"
        botonCompletar.setTitle("Tarea completada", for: .normal)
        botonCompletar.isEnabled = false
    }
    
    @objc func editarTarea() {
        let editarVC = EditarTareaViewController()
        editarVC.nombreTarea = nombreTarea
        
        editarVC.alGuardarCambios = { nuevoNombre in
            self.nombreTarea = nuevoNombre
            self.txtTarea.text = nuevoNombre
            self.alEditarTarea?(nuevoNombre)
        }
        
        navigationController?.pushViewController(editarVC, animated: true)
    }
}
