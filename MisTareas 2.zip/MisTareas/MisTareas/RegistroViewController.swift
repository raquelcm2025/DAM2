import UIKit
import FirebaseAuth

class RegistroViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtContrasenia: UITextField!
    @IBOutlet weak var txtConfirmar: UITextField!
    @IBOutlet weak var botonRegistrar: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func crearCuenta(_ sender: Any) {
        guard let email = txtEmail.text, !email.isEmpty,
              let contrasenia = txtContrasenia.text, !contrasenia.isEmpty,
              let confirmar = txtConfirmar.text, !confirmar.isEmpty else {
            mostrarAlerta("Por favor completa todos los campos.")
            return
        }

        guard contrasenia == confirmar else {
            mostrarAlerta("Las contraseñas no coinciden.")
            return
        }

        guard contrasenia.count >= 6 else {
            mostrarAlerta("La contraseña debe tener al menos 6 caracteres.")
            return
        }

        botonRegistrar.isEnabled = false
        activityIndicator.startAnimating()

        Auth.auth().createUser(withEmail: email, password: contrasenia) { [weak self] _, error in
            guard let self = self else { return }
            self.botonRegistrar.isEnabled = true
            self.activityIndicator.stopAnimating()

            if let error = error {
                self.mostrarAlerta(error.localizedDescription)
                return
            }

            if let sceneDelegate = self.view.window?.windowScene?.delegate as? SceneDelegate {
                sceneDelegate.mostrarTareas()
            }
        }
    }

    func mostrarAlerta(_ mensaje: String) {
        let alerta = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        alerta.addAction(UIAlertAction(title: "OK", style: .default))
        present(alerta, animated: true)
    }
}
