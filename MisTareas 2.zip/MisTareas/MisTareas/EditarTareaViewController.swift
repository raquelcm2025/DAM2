import UIKit

class EditarTareaViewController: UIViewController {
   
   var nombreTarea: String = ""
   var alGuardarCambios: ((String) -> Void)?
   
   let txtTarea = UITextField()
   let botonGuardar = UIButton(type: .system)

   override func viewDidLoad() {
       super.viewDidLoad()
       
       title = "Editar tarea"
       view.backgroundColor = .systemBackground
       
       configurarVista()
   }
   
   func configurarVista() {
       let lblTarea = UILabel()
       lblTarea.text = "Nuevo nombre de la tarea"
       
       txtTarea.text = nombreTarea
       txtTarea.borderStyle = .roundedRect
       txtTarea.placeholder = "Escribe la tarea"
       
       botonGuardar.setTitle("Guardar cambios", for: .normal)
       botonGuardar.backgroundColor = .systemGray5
       botonGuardar.layer.cornerRadius = 8
       botonGuardar.heightAnchor.constraint(equalToConstant: 45).isActive = true
       botonGuardar.addTarget(self, action: #selector(guardarCambios), for: .touchUpInside)
       
       let stack = UIStackView(arrangedSubviews: [
           lblTarea,
           txtTarea,
           botonGuardar
       ])
       
       stack.axis = .vertical
       stack.spacing = 12
       stack.translatesAutoresizingMaskIntoConstraints = false
       
       view.addSubview(stack)
       
       NSLayoutConstraint.activate([
           stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30),
           stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
           stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24)
       ])
   }
   
   @objc func guardarCambios() {
       guard let nuevoNombre = txtTarea.text,
             !nuevoNombre.trimmingCharacters(in: .whitespaces).isEmpty else {
           return
       }
       
       alGuardarCambios?(nuevoNombre)
       navigationController?.popViewController(animated: true)
   }
}
