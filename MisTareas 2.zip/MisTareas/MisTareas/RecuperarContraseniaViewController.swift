import UIKit
import FirebaseAuth

class RecuperarContraseniaViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var botonEnviar: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func enviarEnlace(_ sender: Any) {
        guard let email = txtEmail.text, !email.isEmpty else {
            mostrarAlerta(titulo: "Error", mensaje: "Por favor ingresa tu correo electrónico.")
            return
        }

        botonEnviar.isEnabled = false
        activityIndicator.startAnimating()

        Auth.auth().sendPasswordReset(withEmail: email) { [weak self] error in
            guard let self = self else { return }
            self.botonEnviar.isEnabled = true
            self.activityIndicator.stopAnimating()

            if let error = error {
                self.mostrarAlerta(titulo: "Error", mensaje: error.localizedDescription)
                return
            }

            self.mostrarAlerta(titulo: "Enviado", mensaje: "Revisa tu correo para restablecer tu contraseña.") {
                self.navigationController?.popViewController(animated: true)
            }
        }
    }

    func mostrarAlerta(titulo: String, mensaje: String, completion: (() -> Void)? = nil) {
        let alerta = UIAlertController(title: titulo, message: mensaje, preferredStyle: .alert)
        alerta.addAction(UIAlertAction(title: "OK", style: .default) { _ in completion?() })
        present(alerta, animated: true)
    }
}
