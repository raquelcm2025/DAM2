import UIKit
import FirebaseAuth

class TareasViewController: UITableViewController {

    var tareas = [
        "Comprar materiales",
        "Hacer tarea de iOS",
        "Estudiar Swift",
        "Revisar proyecto"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Mis Pendientes"
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "TareaCell")
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .add,
            target: self,
            action: #selector(agregarTarea)
        )

        navigationItem.leftBarButtonItem = UIBarButtonItem(
            title: "Cerrar sesión",
            style: .plain,
            target: self,
            action: #selector(cerrarSesion)
        )
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tareas.count
    }

    override func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TareaCell", for: indexPath)
        
        var contenido = cell.defaultContentConfiguration()
        contenido.text = tareas[indexPath.row]
        
        cell.contentConfiguration = contenido
        cell.accessoryType = .disclosureIndicator
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let detalleVC = DetalleTareaViewController()
        detalleVC.nombreTarea = tareas[indexPath.row]
        
        detalleVC.alEditarTarea = { nuevoNombre in
            self.tareas[indexPath.row] = nuevoNombre
            self.tableView.reloadRows(at: [indexPath], with: .automatic)
        }
        
        navigationController?.pushViewController(detalleVC, animated: true)
    }
    
    
    override func tableView(
        _ tableView: UITableView,
        trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath
    ) -> UISwipeActionsConfiguration? {
        
        let eliminar = UIContextualAction(style: .destructive, title: "Eliminar") { _, _, completion in
            
            self.tareas.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
            completion(true)
        }
        
        let configuracion = UISwipeActionsConfiguration(actions: [eliminar])
        return configuracion
    }
    @objc func cerrarSesion() {
        let alerta = UIAlertController(title: "Cerrar sesión", message: "¿Estás seguro?", preferredStyle: .alert)
        alerta.addAction(UIAlertAction(title: "Cancelar", style: .cancel))
        alerta.addAction(UIAlertAction(title: "Cerrar sesión", style: .destructive) { _ in
            try? Auth.auth().signOut()
            if let sceneDelegate = self.view.window?.windowScene?.delegate as? SceneDelegate {
                sceneDelegate.mostrarLogin()
            }
        })
        present(alerta, animated: true)
    }

    @objc func agregarTarea() {
        let alerta = UIAlertController(
            title: "Nueva tarea",
            message: "Escribe tu tarea",
            preferredStyle: .alert
        )
        
        alerta.addTextField { textField in
            textField.placeholder = "Nombre de la tarea"
        }
        
        let cancelar = UIAlertAction(title: "Cancelar", style: .cancel)
        
        let agregar = UIAlertAction(title: "Agregar", style: .default) { _ in
            guard let texto = alerta.textFields?.first?.text,
                  !texto.isEmpty else {
                return
            }
            
            self.tareas.append(texto)
            self.tableView.reloadData()
        }
        
        alerta.addAction(cancelar)
        alerta.addAction(agregar)
        
        present(alerta, animated: true)
    }
}
